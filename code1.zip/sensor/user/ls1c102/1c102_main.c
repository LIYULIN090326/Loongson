#include "ls1x.h"
#include "Config.h"
#include "oled.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_adc.h"

// DHT11相关函数
void DHT11_RST(void) {
    gpio_write_pin(GPIO_PIN_23, 0);
    delay_ms(20);
    gpio_write_pin(GPIO_PIN_23, 1);
    delay_us(13);
    
}

uint8_t DHT11_Check(void) {
    uint8_t response = 0;
    delay_us(40);
    if (gpio_get_pin(GPIO_PIN_23) == 0) {
        delay_us(60);
        if (gpio_get_pin(GPIO_PIN_23) == 1) {
            response = 1;
        }
    }
    while (gpio_get_pin(GPIO_PIN_23)); // 等待响应信号结束
    return response;
}



uint8_t DHT11_Init (void){
    //DHT11初始化
    DHT11_RST();								//DHT11端口复位，发出起始信号
    return DHT11_Check(); 						//等待DHT11回应
}

uint8_t DHT11_ReadByte(void) {
    uint8_t i, data = 0;
    for (i = 0; i < 8; i++) {
        while (!gpio_get_pin(GPIO_PIN_23)); // 等待引脚变高
        delay_us(30);
        if (gpio_get_pin(GPIO_PIN_23)) {
            data |= (1 << (7 - i));
        }
        while (gpio_get_pin(GPIO_PIN_23)); // 等待引脚变低
    }
    return data;
}

uint8_t DHT11_ReadData(uint8_t* temperature, uint8_t* humidity) {
    uint8_t buffer[5];
    uint8_t i;
    DHT11_RST();
    if (DHT11_Check()) {
        for (i = 0; i < 5; i++) {
            buffer[i] = DHT11_ReadByte();
        }
        if ((buffer[0] + buffer[1] + buffer[2] + buffer[3]) == buffer[4]) {
            *humidity = buffer[0];
            *temperature = buffer[2];
            return 1;
        }
    }
    return 0;
}
// DHT11相关函数结束


// MQ-2相关函数
uint8_t MQ2_Read(void) {
    // 假设MQ-2传感器输出信号接在GPIO_PIN_25上
    return gpio_get_pin(GPIO_PIN_25); // 读取MQ-2传感器的输出信号
}
// MQ-2相关函数结束


// MK311相关函数
// MK311相关函数结束


int main(int arg, char *args[])
{
    //————————————————————温湿度传感器基本设置———————————————
    uint8_t temperature = 0;
    uint8_t humidity = 0;

    //————————————————————烟雾传感器基本设置————————————————
    int smokeDetected = 0; // 表示烟雾是否检测到的变量
    int adcValue1 = 0; // 存储ADC读数的变量（烟雾）
    int smokePercentage = 0; // 存储烟雾浓度百分比的整数

    //————————————————————水位传感器基本设置————————————————
    int waterLevel = 0; // 存储水位传感器读数的变量
    int adcValue2 = 0; // 存储ADC读数的变量
    int waterPercentage = 0; // 存储水位百分比的整数
    
    //————————————————————初始化——————————————————

    AFIO_RemapConfig(AFIOB, GPIO_Pin_4, 0); // 假设这是用于GPIO_PIN_4的配置
    Adc_powerOn(); // 打开ADC电源
    Adc_open(ADC_CHANNEL_I1); // 打开ADC通道I1（烟雾）
    Adc_open(ADC_CHANNEL_I4); // 打开ADC通道I4（水位）

    gpio_write_pin(GPIO_PIN_20, 1); // 先点亮LED灯
    Spi_Init(SPI_DIV_2); // 初始化SPI
    OLED_Init(); // 初始化OLED
    OLED_Clear(); // 清空OLED屏幕
    gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯

    delay_ms(1000); // 延时1秒

    while(1)
    {
        //——————————————————————————烟雾传感器数据收集——————————————————————
        // 读取ADC数值（烟雾）
        adcValue1 = Adc_getVoltage(ADC_CHANNEL_I1);

        // 读取MQ-2传感器数值（假设有MQ2_Read函数）
        smokeDetected = MQ2_Read(); // 这个函数应该从GPIO_PIN_25读取

        // 将ADC数值映射为百分比浓度（电压范围3.3v）
        smokePercentage = (adcValue1 - 800) * 100 / (3300 - 1000);

        //小于0时烟雾浓度数值为0
        if(smokePercentage < 0){
            smokePercentage = 0;
        }
       
        printf("smokePercentage: %d°C\n", smokePercentage);

        //——————————————————————————水位传感器数据收集——————————————————————
        // 读取ADC数值（水位）
        adcValue2 = Adc_Measure(ADC_CHANNEL_I4);

        // 将ADC数值映射为百分比水位（假设ADC范围是0到4095）
        waterPercentage =(adcValue2 * 100) / 2252;

        printf("Water Percentage: %d%%\n", waterPercentage);





        //——————————————————————————OLED显示屏显示————————————————————————
        //——————————————————在OLED上显示温湿度
        if (DHT11_ReadData(&temperature, &humidity)) {
        
        // LED灯闪烁，用于辅助观察
        //gpio_write_pin(GPIO_PIN_20, 1); // 打开LED灯
        //delay_ms(1000); // 延时100毫秒
        //gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯
        //delay_ms(300); // 延时300毫秒
        
        // 打印到控制台（可选）
        printf("Temperature: %d°C\n", temperature);
        printf("Humidity: %d%%\n", humidity);

        // 在OLED显示屏上显示温度和湿度数据
        OLED_Clear();
        OLED_ShowString(0, 0, "Temp:");
        OLED_ShowNum(40, 0, temperature, 2, 16); // 显示温度，假设温度是两位数字
        OLED_ShowChar(56, 0, 'C', 16);           // 显示单位 'C'
        
        OLED_ShowString(0, 16, "Humidity:");
        OLED_ShowNum(72, 16, humidity, 2, 16);   // 显示湿度，假设湿度是两位数字
        OLED_ShowChar(88, 16, '%', 16);          // 显示百分号
    } else {
        // LED灯闪烁，用于辅助观察
        gpio_write_pin(GPIO_PIN_20, 1); // 打开LED灯
        //delay_ms(1000); // 延时100毫秒
        //gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯
        //delay_ms(300); // 延时300毫秒

        // 显示错误信息
        OLED_Clear();
        OLED_ShowString(0, 0, "Errorreading");
        OLED_ShowString(0, 16, "DHT11sensor");
        return 0;
        
    }



        //——————————————————在OLED上显示烟雾浓度百分比
        
        
        OLED_ShowString(0, 32, "Smoke:");
        OLED_ShowNum(48, 32, smokePercentage, 2, 16);   // 显示湿度，假设湿度是两位数字
        OLED_ShowChar(64, 32, '%', 16);          // 显示百分号

        //if(smokePercentage>=20){
        //    gpio_write_pin(GPIO_PIN_14, 1); // 打开LED灯
        //}else{
        //    gpio_write_pin(GPIO_PIN_14, 0); // 关闭LED灯
        //}

        // 在OLED上显示是否检测到烟雾
        if (smokeDetected == 0 || smokePercentage >= 30) {
            OLED_ShowString(0, 48, "Smoke");
            OLED_ShowString(48, 48, "Detected");
            gpio_write_pin(GPIO_PIN_20, 1); // 打开LED灯

            return 0;

        } else {
            OLED_ShowString(0, 48, "No");
            OLED_ShowString(24, 48, "Smoke");
            
            gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯
        }

        delay_ms(1000); // 延时1秒后更新显示

         //——————————————在OLED上显示水位百分比
        OLED_Clear();
        
        OLED_ShowString(0, 0, "Water:");
        OLED_ShowNum(48, 0, waterPercentage, 2, 16);   // 显示水位百分比，假设是两位数字
        OLED_ShowChar(64, 0, '%', 16);          // 显示百分号

        if(waterPercentage >= 20){
            gpio_write_pin(GPIO_PIN_20, 1); // 打开LED灯
            OLED_ShowString(0, 16, "Water");
            OLED_ShowString(48, 16, "Detected");
            
            return 0;

        } else {
            gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯
            OLED_ShowString(0, 16, "No");
            OLED_ShowString(24, 16, "Water");
        }


        delay_ms(1000); // 延时1秒后更新显示
    }

    return 0;
}
