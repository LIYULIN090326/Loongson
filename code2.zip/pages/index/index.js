// 引入 MQTT 和阿里云连接的相关文件
import mqtt from'../../utils/mqtt.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

let that = null;

Page({
  data: {
    temperature:'' ,
    threshold: 100, 
  },

  data: {
    humidity:'' ,
    threshold: 100, 
  },

  data: {
    smoke:'' ,
    threshold: 50, 
    isAlarm: false 
  },

  data: {
    level:'' ,
    threshold: 10, 
    isAlarm: false 
  },

  data: {
    strain1:'' ,
    threshold: 0.1, 
    isAlarm: false 
  },

  data: {
    strain2:'' ,
    threshold: 0.1, 
    isAlarm: false 
  },

  client: null,// 记录重连的次数
  reconnectCounts: 0,// MQTT 连接的配置
  options: {
    protocolVersion: 4, // MQTT 连接协议版本
    clean: false,
    reconnectPeriod: 1000, // 1000 毫秒，两次重新连接之间的间隔
    connectTimeout: 30 * 1000, // 1000 毫秒，两次重新连接之间的间隔
    resubscribe: true, // 如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认 true）
    clientId: 'a1J61Wvmk5p.WeChat|securemode=2,signmethod=hmacsha256,timestamp=1720504811704|',
    password: 'bf3a0a7cdd2c9c0465855ac8b2325fb75a81f0f04f99a8c6d39f0c833d34cc31',
    username: 'WeChat&a1J61Wvmk5p',
  },

  aliyunInfo: {
    productKey: 'a1J61Wvmk5p', // 阿里云连接的三元组 ，请自己替代为自己的产品信息!!
    deviceName: 'WeChat', // 阿里云连接的三元组 ，请自己替代为自己的产品信息!!
    deviceSecret: '5d0d80a3e2325b7e12085fb34de384d5', // 阿里云连接的三元组 ，请自己替代为自己的产品信息!!
    regionId: 'cn-shanghai', // 阿里云连接的三元组 ，请自己替代为自己的产品信息!!
    pubTopic: '/a1J61Wvmk5p/WeChat/user/WeChat', // 发布消息的主题
    subTopic: 'a1J61Wvmk5p/WeChat/user/get', // 订阅消息的主题
  },

  onLoad: function () {
    that = this;
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: that.data.aliyunInfo.productKey,
      deviceName: that.data.aliyunInfo.deviceName,
      deviceSecret: that.data.aliyunInfo.deviceSecret,
      regionId: that.data.aliyunInfo.regionId,
      port: that.data.aliyunInfo.port,
    });

    console.log("get data:" + JSON.stringify(clientOpt));
    let host = 'wxs://' + clientOpt.host;

    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));

    // 访问服务器
    this.data.client = mqtt.connect(host, this.data.options);

    this.data.client.on('connect', function (connack) {
      wx.showToast({
        title: '连接成功'
      })
      console.log("连接成功");
    })

    // 接收消息监听
    that.data.client.on("message", function (topic, payload) {
      // message 是一个 16 进制的字节流
      let dataFromALY = {};
      try {
        dataFromALY = JSON.parse(payload);
        console.log(dataFromALY);

        // 调用 updateSmokeValue 函数更新数据和报警状态
        that.updateSmokeValue(dataFromALY.smoke); 
      } catch (error) {
        console.log(error);
      }
    })

    // 服务器连接异常的回调
    that.data.client.on("error", function (error) {
      console.log(" 服务器 error 的回调" + error)

    })
    // 服务器重连连接异常的回调
    that.data.client.on("reconnect", function () {
      console.log(" 服务器 reconnect 的回调")

    })
    // 服务器连接异常的回调
    that.data.client.on("offline", function (errr) {
      console.log(" 服务器 offline 的回调")
    })
  },

  // 假设从服务器获取或更新 smoke 值的函数
  updateSmokeValue(newSmokeValue) {
    this.setData({
      smoke: newSmokeValue
    });

    if (newSmokeValue > this.data.threshold) {
      this.setData({
        isAlarm: true
      });
    } else {
      this.setData({
        isAlarm: false
      });
    }
  },

  onClickOpen() {
    that.sendCommond(1);
  },

  onClickOff() {
    that.sendCommond(0);
  },

  sendCommond(data) {
    let sendData = {
      LightSwitch: data,
    };

    // 此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅 topic，因此把他放在这个确保订阅 topic 的时候已成功连接服务器
    // 订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
    this.data.client.subscribe(this.data.aliyunInfo.subTopic, function (err) {
      if (!err) {
        console.log("订阅成功");
      };
      wx.showModal({
        content: "订阅成功",
        showCancel: false,
      })
    })

    // 发布消息
    if (this.data.client && this.data.client.connected) {
      this.data.client.publish(this.data.aliyunInfo.pubTopic, JSON.stringify(sendData));
      console.log(this.data.aliyunInfo.pubTopic)
      console.log(JSON.stringify(sendData))
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  }
})
